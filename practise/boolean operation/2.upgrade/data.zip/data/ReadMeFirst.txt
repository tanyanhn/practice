the file data/Result/sol* includes:
result0.txt - result*.txt 

result0.txt contains two lines of data:
the first line contains the partial order of the result1.txt- result*.txt.
e.g. for the panda data:
the partial order is:  1 2 3 4 8 5 9 10 6 7 

the second line contains the orientation of each loop.
e.g. for the Result/data/pandadata:

1  2   3  4  8  5  9 10  6  7 
1 -1  -1  1 -1  1 -1  1  1  1




result1.txt-result*.txt contain some loops of result data, also two lines:
the first line is x axis, the second line is y axis.

