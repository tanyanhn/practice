
	function y = ux_mol(t,x)

	y = exp(-t)*sin(pi*x);
