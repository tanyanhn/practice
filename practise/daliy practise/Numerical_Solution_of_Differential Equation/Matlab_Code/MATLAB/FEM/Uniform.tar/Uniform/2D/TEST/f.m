
   function f = f(x,y)

% 	f = 0;
%	f = pi*pi*cos(pi*x);
%	f= -4;
%	f = 2*pi*pi*cos(pi*x)*cos(pi*y);
	f = exp(x)*cos(pi*y)*(pi*pi-1);

   return
