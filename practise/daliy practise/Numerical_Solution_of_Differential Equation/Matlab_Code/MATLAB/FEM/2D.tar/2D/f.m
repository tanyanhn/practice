
   function f = f(x,y)

% 	f = 0;
%	f = pi*pi*cos(pi*x);
	f= -4;

   return
