
function y = f(x)

  % y = pi*pi*sin(pi*x);
  % y = x^3;
%    y = (pi*pi+1)*sin(pi*x);
    y = -(x^2)/2+x/2+1
return
