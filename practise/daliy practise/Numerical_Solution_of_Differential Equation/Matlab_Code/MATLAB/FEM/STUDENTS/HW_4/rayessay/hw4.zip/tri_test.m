
D=6
M=pi

h=zeros(7)
x=linspace(0,M/D,10)
for i=0:6
  h=triangularPulse((i-1)*pi/3,i*pi/3,0);
end
i=1
[triangularPulse((i-1)*pi/3,i*pi/3,(i-1)*pi/3 )
triangularPulse((i-1)*pi/3,i*pi/3, i*pi/6)
triangularPulse((i-1)*pi/3,i*pi/3, i*pi/3)]

