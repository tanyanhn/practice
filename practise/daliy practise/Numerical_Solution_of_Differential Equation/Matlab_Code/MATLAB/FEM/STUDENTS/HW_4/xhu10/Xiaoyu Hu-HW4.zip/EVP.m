function EVP(x)

%     for piecewise test function only!!!
%     for uniform mesh
%     bc: left: Dirichlet, right: Robin   
    global gk
    
    a=0;
    b=pi;
    
    N = length(x);
    gB = zeros(N-1,N-1);
    gA = zeros(N-1,N-1);
    
    for i=1:N-1
        h(i)=x(i+1)-x(i);
    end
  
    gB(1,1)=h(i)/3*2;
    gB(1,2)=h(i)/6;
    gB(2,1)=h(i)/6;
    gB(N-1,N-1)=h(i)/3;
    gB(2,2)=h(i)/3;
    for i=2:N-2
        gB(i,i)=gB(i,i)+h(i)/3;
        gB(i,i+1)=gB(i,i+1)+h(i)/6;
        gB(i+1,i)=gB(i+1,i)+h(i)/6;
        gB(i+1,i+1)=gB(i+1,i+1)+h(i)/3;
    end

    for i=1:N-1
        for j=1:N-1
            gA(i,j) = gk(i+1,j+1);
        end
    end
   
    [V,D]=eig(gA,gB);
    
    [ev,I]= sort(diag(D));
    ef=V(:,I);

    figure(1)
    hold on
    for i=1:N-1
        eignFunc =[0;ef(:,i)];
        xxx=linspace(a,b,length(eignFunc));
        plot ( xxx,eignFunc )
    end

    for i=1:N-1
        eignFunc(:,i) =[0;ef(:,i)];
    end
    
    figure(2)
    hold on
    xxx=linspace(a,b,100);
    for i=1:length(xxx)
        for j=1:N-1
            y(i,j)=eigenfun(x,eignFunc(:,j),xxx(i));
        end
    end
    for i=1:2
        plot ( xxx,y(:,i) )
    end
    
    ev
    
    return
    
end
