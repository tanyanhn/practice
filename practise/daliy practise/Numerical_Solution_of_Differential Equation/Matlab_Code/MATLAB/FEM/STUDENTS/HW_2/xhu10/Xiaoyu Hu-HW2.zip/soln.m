
function u = soln(x)

 u = x*(1-x)/2;
%   u=sin(pi*x);
 % u = -1/20*(x^5)+1/20 * x;
%  if x>=0 & x<=0.5
%      u=0.5*x;
%  end
%  if x>0.5 & x<=1
%      u=-0.5*(x-1);
 end
