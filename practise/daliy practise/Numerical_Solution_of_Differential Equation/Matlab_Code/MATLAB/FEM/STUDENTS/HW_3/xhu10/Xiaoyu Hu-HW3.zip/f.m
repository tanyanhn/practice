
function y = f(x)

  % y = pi*pi*sin(pi*x);
  % y = x^3;
%    y = (pi*pi+1)*sin(pi*x);
    y = 1;
return
