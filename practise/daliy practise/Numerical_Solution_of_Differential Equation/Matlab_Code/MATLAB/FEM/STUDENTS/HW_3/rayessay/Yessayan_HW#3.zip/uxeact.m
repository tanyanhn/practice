
    function [y] = uxeact(x)

%   y = 1 + 2*x-3*x*x;

    y = sin(x);
    y = exp(x)*sin(x) %%HW3

    return 
