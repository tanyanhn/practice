
function yp = uexact(x,y)
 
    yp = .25*(x^2+y^4)*sin(pi*x)*cos(4*pi*y);

return


