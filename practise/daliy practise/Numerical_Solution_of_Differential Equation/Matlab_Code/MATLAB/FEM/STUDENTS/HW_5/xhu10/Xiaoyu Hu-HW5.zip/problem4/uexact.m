
function yp = uexact(x,y)
 
    yp = (x^2 + y^4)/4 * sin(pi*x)*cos(4*pi*y);

return


