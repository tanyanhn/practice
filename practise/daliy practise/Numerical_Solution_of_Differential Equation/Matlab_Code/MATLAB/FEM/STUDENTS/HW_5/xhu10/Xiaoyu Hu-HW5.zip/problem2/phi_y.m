function  p = phi_y( i,h,x,y )
    
    switch i
        case 1
            p=1/h+0.*x+0.*y;
        case 2
            p=1/h+0.*x+0.*y;
        case 3
            p=0;
        case 4
            p=-1/h+0.*x+0.*y;
        case 5
            p=-1/h+0.*x+0.*y;
        case 6
            p=0;
    end

end

