function  p = phi( ii,i,j,h,x,y )
    
    switch ii
        case 1
            p=1/h*(x-(i-1)*h+y-(j-1)*h)-1;
        case 2
            p=1/h*(y-(j-1)*h)+0.*x;
        case 3
            p=1/h*(h-(x-i*h))+0.*y;
        case 4
            p=1-1/h*(x-i*h+y-j*h);
        case 5
            p=1/h*(h-(y-j*h))+0.*x;
        case 6
            p=1/h*(x-(i-1)*h)+0.*y;
    end

end

