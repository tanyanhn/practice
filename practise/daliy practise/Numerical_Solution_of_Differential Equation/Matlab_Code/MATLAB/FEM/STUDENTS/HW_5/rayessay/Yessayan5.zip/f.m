
   function f = f(x,y)

% 	f = 0;
%	f = pi*pi*cos(pi*x);
    uxx= 1/4 * cos(4*pi*y)*(2*sin(pi*x) - pi^2*x^2*sin(pi*x)-pi^2*y^4*sin(pi*x)+4*pi*x*cos(pi*x))
    uyy = -(sin(pi*x)*(4*pi^2*x^2*cos(4*pi*y)-3*y^2*cos(4*pi*y)+4*pi^2*y^4*cos(4*pi*y)+8*pi*y^3*sin(4*pi*y)))
	f= -(uxx+uyy)

   return
