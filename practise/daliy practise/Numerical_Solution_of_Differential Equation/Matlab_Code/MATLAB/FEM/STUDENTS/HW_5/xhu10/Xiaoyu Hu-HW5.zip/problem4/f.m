
   function f = f(x,y)

% 	f = 0;
%	f = pi*pi*cos(pi*x);
	f= 17*pi^2*cos(4*pi*y)*sin(pi*x)*(x^2/4 + y^4/4) - 3*y^2*cos(4*pi*y)*sin(pi*x) - (cos(4*pi*y)*sin(pi*x))/2 - x*pi*cos(pi*x)*cos(4*pi*y) + 8*y^3*pi*sin(pi*x)*sin(4*pi*y);
    
%     syms x y q qq
% 
%     q = (x^2 + y^4)/4 * sin(pi*x)*cos(4*pi*y);
%     
%     qx=diff(q,x);
%     qxx=diff(qx,x);
%     qy=diff(q,y);
%     qyy=diff(qy,y);
%     qq=-(qxx+qyy)
   return
