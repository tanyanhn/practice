
function g1 = g1(t);
 
    g1 = cos(t);

% Exact solution is u = cos(t) *cos(pi*x); a=0, b=1.
