
function y = uexact(t,x)
   y = cos(t)*sin(pi*x);

