function temp = temp(t)
temp = 70 + 130*exp(-t/26);
