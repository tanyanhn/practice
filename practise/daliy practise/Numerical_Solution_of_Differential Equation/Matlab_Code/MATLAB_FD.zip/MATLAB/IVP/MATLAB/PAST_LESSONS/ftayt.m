function ftayt = ftayt(t,x)
    ftayt = 0.;
