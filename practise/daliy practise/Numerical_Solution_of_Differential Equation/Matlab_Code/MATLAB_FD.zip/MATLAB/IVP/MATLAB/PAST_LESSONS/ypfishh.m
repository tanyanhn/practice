function f = ypfishh(t,y)
global c M

f = c*(M-y)*y-0.2;