function ftayu = ftayu(t,x)
    ftayu = -2/155;
