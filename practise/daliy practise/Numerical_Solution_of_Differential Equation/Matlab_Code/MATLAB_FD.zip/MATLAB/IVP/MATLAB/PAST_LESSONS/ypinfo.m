function ypinfo = ypinfo(t,y)
  ypinfo(1) = (.01)*(20000 -y(1));
