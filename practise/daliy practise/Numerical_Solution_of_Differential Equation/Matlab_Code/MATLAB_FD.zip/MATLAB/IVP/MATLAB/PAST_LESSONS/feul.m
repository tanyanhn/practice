function feul = feul(t,x)
  feul = .061*(1+.348384310)*(70.+3*t/5 - x);
