
x0=0; y0=-0.5; xfinal=2; n=40;
[x,y] = euler_simple(x0,y0,xfinal,n);

plot(x,y)


