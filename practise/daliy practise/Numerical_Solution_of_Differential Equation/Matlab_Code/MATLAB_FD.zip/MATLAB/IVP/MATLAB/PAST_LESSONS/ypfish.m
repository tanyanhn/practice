function ypfish = ypfish(t,y)
  ypfish(1) = (1/18)*y(1)*(10 -y(1));
