
function v = f(x,y)              % Input x, y; Output: f
    v = 3-x -x*y;
  return       
