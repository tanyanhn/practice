
function w = f3(x,y)
  w = x*x - 2*y/x;

