
x0=0; y0=1; xfinal=2*pi; n1=40;
[x1,y1] = euler_simple2(x0,y0,xfinal,n1);

plot(x1,y1,'o')


