
function y = f(x)
  y = -pi*pi*cos(pi*x);

