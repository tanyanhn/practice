
  function u = uexact(t,x,y)

      u = exp(-t)*sin(pi*x)*cos(pi*y);

