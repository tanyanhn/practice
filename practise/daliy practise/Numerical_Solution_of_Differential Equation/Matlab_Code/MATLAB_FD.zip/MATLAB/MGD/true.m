function y = true(x);

  y = -cos(x) + x*( cos(1)  - 1) + 1;

