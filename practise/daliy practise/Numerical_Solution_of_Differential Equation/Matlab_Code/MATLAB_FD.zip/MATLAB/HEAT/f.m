
  function f = f(t,x)

      f = -sin(t)*sin(pi*x) + cos(t) *sin(pi*x)*pi*pi;

% Exact solution is u = cos(t) *cos(pi*x); a=0, b=1.
% f(x,x) = u_t - u_xx


