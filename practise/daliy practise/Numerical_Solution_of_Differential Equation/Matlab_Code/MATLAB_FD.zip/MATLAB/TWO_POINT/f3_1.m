
function y=f3_1(x)

y = exp(-x)*( -9* x^3 + 18 *x^2 -13 *x + 7 + x^4);

	return

