
function y=ga(x)

y = x;

