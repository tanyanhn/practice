function y = bc(t)

	y = sin(t);
