function y = u0(x)

if x >= 0.5
  y = 1.0;
else
  y = 0.0;
end

