  function u = uexact(t,x,y)
      u = cos(t)*cos(pi*y)*(x*x+1);