  function f = f(t,x,y)
      f = cos(pi*y)*(-sin(t)*(x*x+1)+cos(t)*((pi*pi)*(x*x+1)-2));