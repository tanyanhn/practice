
  function f = f(t,x)

      f = -sin(t)*cos(pi*x) + cos(t) *cos(pi*x)*pi*pi;

% Exact solution is u = cos(t) *cos(pi*x); a=0, b=1.
% f(x,x) = u_t - u_xx


