
function g2 = g2(t);
 
    g2 = -cos(t);

% Exact solution is u = cos(t) *cos(pi*x); a=0, b=1.


