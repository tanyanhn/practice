
  function u = uexact(t,x)

      u = cos(t) *cos(pi*x);

% Exact solution is u = cos(t) *cos(pi*x); a=0, b=1.

