
  function f = f(t,x,y)
      f = exp(-t)*sin(pi*x)*cos(pi*y)*(-1+2*pi*pi);

