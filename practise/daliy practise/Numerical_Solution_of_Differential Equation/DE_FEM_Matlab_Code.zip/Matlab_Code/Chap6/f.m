
function y = f(x)

   y = pi*pi*sin(pi*x);

return
