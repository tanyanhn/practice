
function u = soln(x)

  u = x*(1-x)/2;
  u=sin(pi*x);

