
function yp = uexact(x,y)
 
    yp = x*x + y*y;

return


