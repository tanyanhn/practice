
function y = g(x);

  y = cos(x);
