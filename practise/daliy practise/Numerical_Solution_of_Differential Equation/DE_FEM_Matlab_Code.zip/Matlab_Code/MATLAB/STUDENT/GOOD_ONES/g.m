  function g = g(t,y)
  b=1; q=1; p=1;
  g =cos(t)*cos(pi*y)*(p*(b+1)+2*b*q);
