
 function y=beta(x)

   y = 1+ x*x;
