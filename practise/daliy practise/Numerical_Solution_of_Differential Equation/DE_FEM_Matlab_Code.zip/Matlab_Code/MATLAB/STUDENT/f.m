
function y=f(t,x)

    y = -sin(t)*sin(pi*x) + pi*pi*cos(t)*sin(pi*x);
