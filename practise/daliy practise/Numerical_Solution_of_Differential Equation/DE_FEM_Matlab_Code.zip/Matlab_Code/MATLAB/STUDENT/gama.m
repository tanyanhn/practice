
 function y=gama(x)

   y = x ;
