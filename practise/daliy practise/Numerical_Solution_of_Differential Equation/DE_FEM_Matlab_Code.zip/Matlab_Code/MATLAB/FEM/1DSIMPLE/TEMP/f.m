
function y = f(x)

   y = 1;

return
