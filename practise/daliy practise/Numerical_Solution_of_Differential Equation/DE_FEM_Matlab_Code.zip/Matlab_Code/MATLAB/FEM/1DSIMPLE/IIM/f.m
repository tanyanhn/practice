
function y = f(x)

   y = 0;

return
