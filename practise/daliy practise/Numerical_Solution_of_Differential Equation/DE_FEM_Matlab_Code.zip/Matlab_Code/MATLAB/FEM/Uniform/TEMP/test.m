
% A test example:

  u(x) = sin(x),  a <= x <= b.

  k(x) = 1 + x

  c(x) = cos(x)

  b(x) = x^2

  f(x) = (1+x) sin(x) - cos(x) + cos^2(x) + x^2 sin(x).

