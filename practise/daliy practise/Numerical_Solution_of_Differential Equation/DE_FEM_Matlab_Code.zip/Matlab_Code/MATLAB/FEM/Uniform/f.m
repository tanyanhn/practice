
function yp=f(x)

%    yp = 1;
     yp = x;
