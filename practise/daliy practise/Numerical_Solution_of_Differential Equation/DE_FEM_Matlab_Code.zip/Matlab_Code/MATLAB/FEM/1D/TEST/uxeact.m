
    function [y] = uxeact(x)

%   y = 1 + 2*x-3*x*x;

    y = sin(x);

    return 
