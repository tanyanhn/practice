
% A test example:

  u(x) = sin(x),  a <= x <= b.

u(x) =  sin(x),   pi/2 < x < 4

  k(x) = 1 + x

  c(x) = cos(x)

  q(x) = x^2

  f(x) = (1+x) sin(x) - cos(x) + cos^2(x) + x^2 sin(x).

