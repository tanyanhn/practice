function flr = flr(t,y)
     flr = 2*(70+30*sin(pi*t*5) - y);
