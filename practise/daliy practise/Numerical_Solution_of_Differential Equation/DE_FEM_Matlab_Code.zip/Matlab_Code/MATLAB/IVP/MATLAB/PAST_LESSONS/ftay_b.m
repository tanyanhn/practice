function y = ftay_b(t,x)

    c = 1/26; usur  = 70;
    y = c*(usur- x);
