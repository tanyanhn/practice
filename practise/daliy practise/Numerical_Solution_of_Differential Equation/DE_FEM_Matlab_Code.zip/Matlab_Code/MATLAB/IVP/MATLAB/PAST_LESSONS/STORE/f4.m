
function w = f3(x,y)
  w = y + x*sin(y);

