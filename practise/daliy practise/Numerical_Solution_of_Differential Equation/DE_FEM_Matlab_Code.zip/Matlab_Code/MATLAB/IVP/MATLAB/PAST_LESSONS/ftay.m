function ftay = ftay(t,x)
    ftay = (2/155)*(102 - x);
