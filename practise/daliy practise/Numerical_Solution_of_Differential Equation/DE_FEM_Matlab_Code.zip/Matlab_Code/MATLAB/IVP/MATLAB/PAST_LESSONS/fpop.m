function fpop = fpop(t,x)
    fpop = .01*(100 - x)*x;
