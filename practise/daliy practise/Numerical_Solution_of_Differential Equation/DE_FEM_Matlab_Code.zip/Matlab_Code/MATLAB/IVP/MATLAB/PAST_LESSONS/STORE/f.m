
function yp = f(x,y)
  yp = x + y;
