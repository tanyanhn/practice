
function w = f2(x,y)
  w = sin(x*y);

