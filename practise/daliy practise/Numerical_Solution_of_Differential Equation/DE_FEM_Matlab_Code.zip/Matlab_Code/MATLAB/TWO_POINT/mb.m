
function y=mb(x)

y = 1 + x*x;



