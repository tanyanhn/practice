
function y = fhw1_5a(x)
  y = -pi^2*cos(pi*x) - (1+x^2)*pi*sin(pi*x) + x*cos(pi*x)	;
