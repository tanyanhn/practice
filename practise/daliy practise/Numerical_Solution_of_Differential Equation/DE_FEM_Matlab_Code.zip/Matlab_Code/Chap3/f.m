
function f = f(x,y)
 
%  f= 4;
   f = exp(-x)*sin(pi*y)*(1-pi*pi);
