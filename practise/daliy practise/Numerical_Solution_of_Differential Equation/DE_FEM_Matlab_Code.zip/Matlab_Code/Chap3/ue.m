
function f = ue_h2_3(x,y)

%   f = x*x + y*y;
    f = exp(-x)*sin(pi*y);
