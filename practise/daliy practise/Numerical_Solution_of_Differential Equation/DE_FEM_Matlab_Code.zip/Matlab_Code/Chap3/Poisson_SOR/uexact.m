
function u = uexact(x,y)
  u = exp(x)*sin(pi*y);
return
