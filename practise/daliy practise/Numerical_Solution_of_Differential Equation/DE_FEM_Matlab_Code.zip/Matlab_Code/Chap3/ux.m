
function f = ux_h2_3(y)

%   f = 2;
    f = -exp(-1)*sin(pi*y);

