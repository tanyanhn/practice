
function f = f2d1(x,y)
  f = exp(x)*sin(pi*y)*(1-pi*pi);
return

