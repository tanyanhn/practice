
function f = ux(y)

%   f = 2;
    f = -exp(-1)*sin(pi*y);

